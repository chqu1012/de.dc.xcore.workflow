/**
 */
package de.dc.xcore.workflow.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Delete</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.xcore.workflow.model.Delete#isRekursiv <em>Rekursiv</em>}</li>
 * </ul>
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getDelete()
 * @model
 * @generated
 */
public interface Delete extends Copy {
	/**
	 * Returns the value of the '<em><b>Rekursiv</b></em>' attribute.
	 * The default value is <code>"true"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rekursiv</em>' attribute.
	 * @see #setRekursiv(boolean)
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getDelete_Rekursiv()
	 * @model default="true" unique="false"
	 * @generated
	 */
	boolean isRekursiv();

	/**
	 * Sets the value of the '{@link de.dc.xcore.workflow.model.Delete#isRekursiv <em>Rekursiv</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rekursiv</em>' attribute.
	 * @see #isRekursiv()
	 * @generated
	 */
	void setRekursiv(boolean value);

} // Delete
