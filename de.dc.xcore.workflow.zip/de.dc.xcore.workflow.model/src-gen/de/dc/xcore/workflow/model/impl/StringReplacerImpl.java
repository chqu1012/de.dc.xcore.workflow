/**
 */
package de.dc.xcore.workflow.model.impl;

import de.dc.xcore.workflow.model.StringReplacer;
import de.dc.xcore.workflow.model.WorkflowPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>String Replacer</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link de.dc.xcore.workflow.model.impl.StringReplacerImpl#getRegex <em>Regex</em>}</li>
 *   <li>{@link de.dc.xcore.workflow.model.impl.StringReplacerImpl#getReplacer <em>Replacer</em>}</li>
 *   <li>{@link de.dc.xcore.workflow.model.impl.StringReplacerImpl#isReplaceAll <em>Replace All</em>}</li>
 * </ul>
 *
 * @generated
 */
public class StringReplacerImpl extends ClipboardImpl implements StringReplacer {
	/**
	 * The default value of the '{@link #getRegex() <em>Regex</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRegex()
	 * @generated
	 * @ordered
	 */
	protected static final String REGEX_EDEFAULT = "";

	/**
	 * The cached value of the '{@link #getRegex() <em>Regex</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRegex()
	 * @generated
	 * @ordered
	 */
	protected String regex = REGEX_EDEFAULT;

	/**
	 * The default value of the '{@link #getReplacer() <em>Replacer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReplacer()
	 * @generated
	 * @ordered
	 */
	protected static final String REPLACER_EDEFAULT = "";

	/**
	 * The cached value of the '{@link #getReplacer() <em>Replacer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReplacer()
	 * @generated
	 * @ordered
	 */
	protected String replacer = REPLACER_EDEFAULT;

	/**
	 * The default value of the '{@link #isReplaceAll() <em>Replace All</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isReplaceAll()
	 * @generated
	 * @ordered
	 */
	protected static final boolean REPLACE_ALL_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isReplaceAll() <em>Replace All</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isReplaceAll()
	 * @generated
	 * @ordered
	 */
	protected boolean replaceAll = REPLACE_ALL_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StringReplacerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WorkflowPackage.Literals.STRING_REPLACER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getRegex() {
		return regex;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRegex(String newRegex) {
		String oldRegex = regex;
		regex = newRegex;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowPackage.STRING_REPLACER__REGEX, oldRegex, regex));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getReplacer() {
		return replacer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setReplacer(String newReplacer) {
		String oldReplacer = replacer;
		replacer = newReplacer;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowPackage.STRING_REPLACER__REPLACER, oldReplacer, replacer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isReplaceAll() {
		return replaceAll;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setReplaceAll(boolean newReplaceAll) {
		boolean oldReplaceAll = replaceAll;
		replaceAll = newReplaceAll;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowPackage.STRING_REPLACER__REPLACE_ALL, oldReplaceAll, replaceAll));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case WorkflowPackage.STRING_REPLACER__REGEX:
				return getRegex();
			case WorkflowPackage.STRING_REPLACER__REPLACER:
				return getReplacer();
			case WorkflowPackage.STRING_REPLACER__REPLACE_ALL:
				return isReplaceAll();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case WorkflowPackage.STRING_REPLACER__REGEX:
				setRegex((String)newValue);
				return;
			case WorkflowPackage.STRING_REPLACER__REPLACER:
				setReplacer((String)newValue);
				return;
			case WorkflowPackage.STRING_REPLACER__REPLACE_ALL:
				setReplaceAll((Boolean)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case WorkflowPackage.STRING_REPLACER__REGEX:
				setRegex(REGEX_EDEFAULT);
				return;
			case WorkflowPackage.STRING_REPLACER__REPLACER:
				setReplacer(REPLACER_EDEFAULT);
				return;
			case WorkflowPackage.STRING_REPLACER__REPLACE_ALL:
				setReplaceAll(REPLACE_ALL_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case WorkflowPackage.STRING_REPLACER__REGEX:
				return REGEX_EDEFAULT == null ? regex != null : !REGEX_EDEFAULT.equals(regex);
			case WorkflowPackage.STRING_REPLACER__REPLACER:
				return REPLACER_EDEFAULT == null ? replacer != null : !REPLACER_EDEFAULT.equals(replacer);
			case WorkflowPackage.STRING_REPLACER__REPLACE_ALL:
				return replaceAll != REPLACE_ALL_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (regex: ");
		result.append(regex);
		result.append(", replacer: ");
		result.append(replacer);
		result.append(", replaceAll: ");
		result.append(replaceAll);
		result.append(')');
		return result.toString();
	}

} //StringReplacerImpl
