/**
 */
package de.dc.xcore.workflow.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Date Control</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.xcore.workflow.model.DateControl#getFormatter <em>Formatter</em>}</li>
 * </ul>
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getDateControl()
 * @model
 * @generated
 */
public interface DateControl extends TextControl {
	/**
	 * Returns the value of the '<em><b>Formatter</b></em>' attribute.
	 * The default value is <code>"dd-MM-yyyy hh:mm:ss"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Formatter</em>' attribute.
	 * @see #setFormatter(String)
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getDateControl_Formatter()
	 * @model default="dd-MM-yyyy hh:mm:ss" unique="false"
	 * @generated
	 */
	String getFormatter();

	/**
	 * Sets the value of the '{@link de.dc.xcore.workflow.model.DateControl#getFormatter <em>Formatter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Formatter</em>' attribute.
	 * @see #getFormatter()
	 * @generated
	 */
	void setFormatter(String value);

} // DateControl
