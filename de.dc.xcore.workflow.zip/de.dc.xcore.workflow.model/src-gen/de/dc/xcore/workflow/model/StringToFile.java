/**
 */
package de.dc.xcore.workflow.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>String To File</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.xcore.workflow.model.StringToFile#getExtendsion <em>Extendsion</em>}</li>
 * </ul>
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getStringToFile()
 * @model
 * @generated
 */
public interface StringToFile extends Clipboard {
	/**
	 * Returns the value of the '<em><b>Extendsion</b></em>' attribute.
	 * The default value is <code>"txt"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Extendsion</em>' attribute.
	 * @see #setExtendsion(String)
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getStringToFile_Extendsion()
	 * @model default="txt" unique="false"
	 * @generated
	 */
	String getExtendsion();

	/**
	 * Sets the value of the '{@link de.dc.xcore.workflow.model.StringToFile#getExtendsion <em>Extendsion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Extendsion</em>' attribute.
	 * @see #getExtendsion()
	 * @generated
	 */
	void setExtendsion(String value);

} // StringToFile
