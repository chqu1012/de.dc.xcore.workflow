/**
 */
package de.dc.xcore.workflow.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Svn Commit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getSvnCommit()
 * @model
 * @generated
 */
public interface SvnCommit extends Operation {
} // SvnCommit
