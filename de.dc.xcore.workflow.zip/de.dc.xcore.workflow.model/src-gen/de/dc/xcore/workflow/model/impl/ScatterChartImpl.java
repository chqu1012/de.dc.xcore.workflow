/**
 */
package de.dc.xcore.workflow.model.impl;

import de.dc.xcore.workflow.model.ScatterChart;
import de.dc.xcore.workflow.model.WorkflowPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Scatter Chart</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ScatterChartImpl extends ChartImpl implements ScatterChart {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ScatterChartImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WorkflowPackage.Literals.SCATTER_CHART;
	}

} //ScatterChartImpl
