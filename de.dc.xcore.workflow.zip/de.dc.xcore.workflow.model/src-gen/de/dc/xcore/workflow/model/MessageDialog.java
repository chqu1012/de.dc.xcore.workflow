/**
 */
package de.dc.xcore.workflow.model;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Message Dialog</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getMessageDialog()
 * @model
 * @generated
 */
public interface MessageDialog extends EObject {
} // MessageDialog
