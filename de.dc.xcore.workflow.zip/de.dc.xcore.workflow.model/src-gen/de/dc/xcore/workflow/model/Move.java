/**
 */
package de.dc.xcore.workflow.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Move</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getMove()
 * @model
 * @generated
 */
public interface Move extends Copy {
} // Move
