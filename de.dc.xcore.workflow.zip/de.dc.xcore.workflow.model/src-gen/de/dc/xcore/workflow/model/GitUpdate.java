/**
 */
package de.dc.xcore.workflow.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Git Update</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getGitUpdate()
 * @model
 * @generated
 */
public interface GitUpdate extends Operation {
} // GitUpdate
