/**
 */
package de.dc.xcore.workflow.model;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Info Dialog</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getInfoDialog()
 * @model
 * @generated
 */
public interface InfoDialog extends EObject {
} // InfoDialog
