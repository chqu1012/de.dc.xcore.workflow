/**
 */
package de.dc.xcore.workflow.model;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Content</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.xcore.workflow.model.Content#getContent <em>Content</em>}</li>
 *   <li>{@link de.dc.xcore.workflow.model.Content#getReplacements <em>Replacements</em>}</li>
 * </ul>
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getContent()
 * @model abstract="true"
 * @generated
 */
public interface Content extends EObject {
	/**
	 * Returns the value of the '<em><b>Content</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Content</em>' attribute.
	 * @see #setContent(String)
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getContent_Content()
	 * @model default="" unique="false"
	 * @generated
	 */
	String getContent();

	/**
	 * Sets the value of the '{@link de.dc.xcore.workflow.model.Content#getContent <em>Content</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Content</em>' attribute.
	 * @see #getContent()
	 * @generated
	 */
	void setContent(String value);

	/**
	 * Returns the value of the '<em><b>Replacements</b></em>' containment reference list.
	 * The list contents are of type {@link de.dc.xcore.workflow.model.Replacement}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Replacements</em>' containment reference list.
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getContent_Replacements()
	 * @model containment="true"
	 * @generated
	 */
	EList<Replacement> getReplacements();

} // Content
