/**
 */
package de.dc.xcore.workflow.model;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Replacer</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getReplacer()
 * @model abstract="true"
 * @generated
 */
public interface Replacer extends EObject {
} // Replacer
