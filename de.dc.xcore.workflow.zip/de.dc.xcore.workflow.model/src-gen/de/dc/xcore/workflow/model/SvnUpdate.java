/**
 */
package de.dc.xcore.workflow.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Svn Update</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getSvnUpdate()
 * @model
 * @generated
 */
public interface SvnUpdate extends Operation {
} // SvnUpdate
