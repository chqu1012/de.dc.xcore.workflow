/**
 */
package de.dc.xcore.workflow.model.impl;

import de.dc.xcore.workflow.model.List;
import de.dc.xcore.workflow.model.Sorter;
import de.dc.xcore.workflow.model.StringToList;
import de.dc.xcore.workflow.model.WorkflowPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>String To List</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link de.dc.xcore.workflow.model.impl.StringToListImpl#getSorter <em>Sorter</em>}</li>
 *   <li>{@link de.dc.xcore.workflow.model.impl.StringToListImpl#getList <em>List</em>}</li>
 * </ul>
 *
 * @generated
 */
public class StringToListImpl extends MinimalEObjectImpl.Container implements StringToList {
	/**
	 * The cached value of the '{@link #getSorter() <em>Sorter</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSorter()
	 * @generated
	 * @ordered
	 */
	protected Sorter sorter;

	/**
	 * The cached value of the '{@link #getList() <em>List</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getList()
	 * @generated
	 * @ordered
	 */
	protected List list;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StringToListImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WorkflowPackage.Literals.STRING_TO_LIST;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Sorter getSorter() {
		return sorter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSorter(Sorter newSorter, NotificationChain msgs) {
		Sorter oldSorter = sorter;
		sorter = newSorter;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, WorkflowPackage.STRING_TO_LIST__SORTER, oldSorter, newSorter);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSorter(Sorter newSorter) {
		if (newSorter != sorter) {
			NotificationChain msgs = null;
			if (sorter != null)
				msgs = ((InternalEObject)sorter).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - WorkflowPackage.STRING_TO_LIST__SORTER, null, msgs);
			if (newSorter != null)
				msgs = ((InternalEObject)newSorter).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - WorkflowPackage.STRING_TO_LIST__SORTER, null, msgs);
			msgs = basicSetSorter(newSorter, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowPackage.STRING_TO_LIST__SORTER, newSorter, newSorter));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List getList() {
		return list;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetList(List newList, NotificationChain msgs) {
		List oldList = list;
		list = newList;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, WorkflowPackage.STRING_TO_LIST__LIST, oldList, newList);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setList(List newList) {
		if (newList != list) {
			NotificationChain msgs = null;
			if (list != null)
				msgs = ((InternalEObject)list).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - WorkflowPackage.STRING_TO_LIST__LIST, null, msgs);
			if (newList != null)
				msgs = ((InternalEObject)newList).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - WorkflowPackage.STRING_TO_LIST__LIST, null, msgs);
			msgs = basicSetList(newList, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowPackage.STRING_TO_LIST__LIST, newList, newList));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case WorkflowPackage.STRING_TO_LIST__SORTER:
				return basicSetSorter(null, msgs);
			case WorkflowPackage.STRING_TO_LIST__LIST:
				return basicSetList(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case WorkflowPackage.STRING_TO_LIST__SORTER:
				return getSorter();
			case WorkflowPackage.STRING_TO_LIST__LIST:
				return getList();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case WorkflowPackage.STRING_TO_LIST__SORTER:
				setSorter((Sorter)newValue);
				return;
			case WorkflowPackage.STRING_TO_LIST__LIST:
				setList((List)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case WorkflowPackage.STRING_TO_LIST__SORTER:
				setSorter((Sorter)null);
				return;
			case WorkflowPackage.STRING_TO_LIST__LIST:
				setList((List)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case WorkflowPackage.STRING_TO_LIST__SORTER:
				return sorter != null;
			case WorkflowPackage.STRING_TO_LIST__LIST:
				return list != null;
		}
		return super.eIsSet(featureID);
	}

} //StringToListImpl
