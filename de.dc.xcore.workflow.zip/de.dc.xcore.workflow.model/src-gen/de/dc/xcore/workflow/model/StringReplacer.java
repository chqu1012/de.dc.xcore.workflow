/**
 */
package de.dc.xcore.workflow.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>String Replacer</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.xcore.workflow.model.StringReplacer#getRegex <em>Regex</em>}</li>
 *   <li>{@link de.dc.xcore.workflow.model.StringReplacer#getReplacer <em>Replacer</em>}</li>
 *   <li>{@link de.dc.xcore.workflow.model.StringReplacer#isReplaceAll <em>Replace All</em>}</li>
 * </ul>
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getStringReplacer()
 * @model
 * @generated
 */
public interface StringReplacer extends Clipboard {
	/**
	 * Returns the value of the '<em><b>Regex</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Regex</em>' attribute.
	 * @see #setRegex(String)
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getStringReplacer_Regex()
	 * @model default="" unique="false"
	 * @generated
	 */
	String getRegex();

	/**
	 * Sets the value of the '{@link de.dc.xcore.workflow.model.StringReplacer#getRegex <em>Regex</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Regex</em>' attribute.
	 * @see #getRegex()
	 * @generated
	 */
	void setRegex(String value);

	/**
	 * Returns the value of the '<em><b>Replacer</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Replacer</em>' attribute.
	 * @see #setReplacer(String)
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getStringReplacer_Replacer()
	 * @model default="" unique="false"
	 * @generated
	 */
	String getReplacer();

	/**
	 * Sets the value of the '{@link de.dc.xcore.workflow.model.StringReplacer#getReplacer <em>Replacer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Replacer</em>' attribute.
	 * @see #getReplacer()
	 * @generated
	 */
	void setReplacer(String value);

	/**
	 * Returns the value of the '<em><b>Replace All</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Replace All</em>' attribute.
	 * @see #setReplaceAll(boolean)
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getStringReplacer_ReplaceAll()
	 * @model default="false" unique="false"
	 * @generated
	 */
	boolean isReplaceAll();

	/**
	 * Sets the value of the '{@link de.dc.xcore.workflow.model.StringReplacer#isReplaceAll <em>Replace All</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Replace All</em>' attribute.
	 * @see #isReplaceAll()
	 * @generated
	 */
	void setReplaceAll(boolean value);

} // StringReplacer
