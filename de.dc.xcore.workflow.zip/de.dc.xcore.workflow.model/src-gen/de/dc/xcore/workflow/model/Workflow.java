/**
 */
package de.dc.xcore.workflow.model;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Workflow</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.xcore.workflow.model.Workflow#isIsRunnable <em>Is Runnable</em>}</li>
 *   <li>{@link de.dc.xcore.workflow.model.Workflow#getOperations <em>Operations</em>}</li>
 *   <li>{@link de.dc.xcore.workflow.model.Workflow#getWorkflows <em>Workflows</em>}</li>
 *   <li>{@link de.dc.xcore.workflow.model.Workflow#getDialogs <em>Dialogs</em>}</li>
 * </ul>
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getWorkflow()
 * @model
 * @generated
 */
public interface Workflow extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Is Runnable</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Runnable</em>' attribute.
	 * @see #setIsRunnable(boolean)
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getWorkflow_IsRunnable()
	 * @model default="false" unique="false"
	 * @generated
	 */
	boolean isIsRunnable();

	/**
	 * Sets the value of the '{@link de.dc.xcore.workflow.model.Workflow#isIsRunnable <em>Is Runnable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Runnable</em>' attribute.
	 * @see #isIsRunnable()
	 * @generated
	 */
	void setIsRunnable(boolean value);

	/**
	 * Returns the value of the '<em><b>Operations</b></em>' containment reference list.
	 * The list contents are of type {@link de.dc.xcore.workflow.model.Operation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operations</em>' containment reference list.
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getWorkflow_Operations()
	 * @model containment="true"
	 * @generated
	 */
	EList<Operation> getOperations();

	/**
	 * Returns the value of the '<em><b>Workflows</b></em>' containment reference list.
	 * The list contents are of type {@link de.dc.xcore.workflow.model.Workflow}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Workflows</em>' containment reference list.
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getWorkflow_Workflows()
	 * @model containment="true"
	 * @generated
	 */
	EList<Workflow> getWorkflows();

	/**
	 * Returns the value of the '<em><b>Dialogs</b></em>' containment reference list.
	 * The list contents are of type {@link de.dc.xcore.workflow.model.InputDialog}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dialogs</em>' containment reference list.
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getWorkflow_Dialogs()
	 * @model containment="true"
	 * @generated
	 */
	EList<InputDialog> getDialogs();

} // Workflow
