/**
 */
package de.dc.xcore.workflow.model.util;

import de.dc.xcore.workflow.model.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see de.dc.xcore.workflow.model.WorkflowPackage
 * @generated
 */
public class WorkflowAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static WorkflowPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WorkflowAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = WorkflowPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WorkflowSwitch<Adapter> modelSwitch =
		new WorkflowSwitch<Adapter>() {
			@Override
			public Adapter caseWorkflowManager(WorkflowManager object) {
				return createWorkflowManagerAdapter();
			}
			@Override
			public Adapter caseWorkflow(Workflow object) {
				return createWorkflowAdapter();
			}
			@Override
			public Adapter caseOperation(Operation object) {
				return createOperationAdapter();
			}
			@Override
			public Adapter caseContent(Content object) {
				return createContentAdapter();
			}
			@Override
			public Adapter casePath(Path object) {
				return createPathAdapter();
			}
			@Override
			public Adapter caseNamedElement(NamedElement object) {
				return createNamedElementAdapter();
			}
			@Override
			public Adapter caseMkdir(Mkdir object) {
				return createMkdirAdapter();
			}
			@Override
			public Adapter caseCopy(Copy object) {
				return createCopyAdapter();
			}
			@Override
			public Adapter caseZip(Zip object) {
				return createZipAdapter();
			}
			@Override
			public Adapter caseMove(Move object) {
				return createMoveAdapter();
			}
			@Override
			public Adapter caseRename(Rename object) {
				return createRenameAdapter();
			}
			@Override
			public Adapter caseDelete(Delete object) {
				return createDeleteAdapter();
			}
			@Override
			public Adapter caseSvnCommit(SvnCommit object) {
				return createSvnCommitAdapter();
			}
			@Override
			public Adapter caseSvnUpdate(SvnUpdate object) {
				return createSvnUpdateAdapter();
			}
			@Override
			public Adapter caseGitCommit(GitCommit object) {
				return createGitCommitAdapter();
			}
			@Override
			public Adapter caseGitUpdate(GitUpdate object) {
				return createGitUpdateAdapter();
			}
			@Override
			public Adapter caseJava(Java object) {
				return createJavaAdapter();
			}
			@Override
			public Adapter caseExe(Exe object) {
				return createExeAdapter();
			}
			@Override
			public Adapter caseClipboard(Clipboard object) {
				return createClipboardAdapter();
			}
			@Override
			public Adapter caseStringSeparator(StringSeparator object) {
				return createStringSeparatorAdapter();
			}
			@Override
			public Adapter caseStringSplitter(StringSplitter object) {
				return createStringSplitterAdapter();
			}
			@Override
			public Adapter caseStringReplacer(StringReplacer object) {
				return createStringReplacerAdapter();
			}
			@Override
			public Adapter caseStringToXls(StringToXls object) {
				return createStringToXlsAdapter();
			}
			@Override
			public Adapter caseStringToFile(StringToFile object) {
				return createStringToFileAdapter();
			}
			@Override
			public Adapter caseQuestionDialog(QuestionDialog object) {
				return createQuestionDialogAdapter();
			}
			@Override
			public Adapter caseInfoDialog(InfoDialog object) {
				return createInfoDialogAdapter();
			}
			@Override
			public Adapter caseMessageDialog(MessageDialog object) {
				return createMessageDialogAdapter();
			}
			@Override
			public Adapter caseSelectionDialog(SelectionDialog object) {
				return createSelectionDialogAdapter();
			}
			@Override
			public Adapter caseFilteredDialog(FilteredDialog object) {
				return createFilteredDialogAdapter();
			}
			@Override
			public Adapter caseEmail(Email object) {
				return createEmailAdapter();
			}
			@Override
			public Adapter caseChart(Chart object) {
				return createChartAdapter();
			}
			@Override
			public Adapter casePoint(Point object) {
				return createPointAdapter();
			}
			@Override
			public Adapter caseLineChart(LineChart object) {
				return createLineChartAdapter();
			}
			@Override
			public Adapter caseBarChart(BarChart object) {
				return createBarChartAdapter();
			}
			@Override
			public Adapter caseScatterChart(ScatterChart object) {
				return createScatterChartAdapter();
			}
			@Override
			public Adapter casePieChart(PieChart object) {
				return createPieChartAdapter();
			}
			@Override
			public Adapter caseStringToList(StringToList object) {
				return createStringToListAdapter();
			}
			@Override
			public Adapter caseSorter(Sorter object) {
				return createSorterAdapter();
			}
			@Override
			public Adapter caseList(List object) {
				return createListAdapter();
			}
			@Override
			public Adapter caseItem(Item object) {
				return createItemAdapter();
			}
			@Override
			public Adapter caseReplacement(Replacement object) {
				return createReplacementAdapter();
			}
			@Override
			public Adapter caseReplacer(Replacer object) {
				return createReplacerAdapter();
			}
			@Override
			public Adapter caseOptionReplacer(OptionReplacer object) {
				return createOptionReplacerAdapter();
			}
			@Override
			public Adapter caseOption(Option object) {
				return createOptionAdapter();
			}
			@Override
			public Adapter caseInputReplacer(InputReplacer object) {
				return createInputReplacerAdapter();
			}
			@Override
			public Adapter caseTimestampReplacer(TimestampReplacer object) {
				return createTimestampReplacerAdapter();
			}
			@Override
			public Adapter caseInputDialog(InputDialog object) {
				return createInputDialogAdapter();
			}
			@Override
			public Adapter caseTextControl(TextControl object) {
				return createTextControlAdapter();
			}
			@Override
			public Adapter caseDateControl(DateControl object) {
				return createDateControlAdapter();
			}
			@Override
			public Adapter caseComboControl(ComboControl object) {
				return createComboControlAdapter();
			}
			@Override
			public Adapter caseComboItem(ComboItem object) {
				return createComboItemAdapter();
			}
			@Override
			public Adapter caseControl(Control object) {
				return createControlAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.WorkflowManager <em>Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.WorkflowManager
	 * @generated
	 */
	public Adapter createWorkflowManagerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Workflow <em>Workflow</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Workflow
	 * @generated
	 */
	public Adapter createWorkflowAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Operation <em>Operation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Operation
	 * @generated
	 */
	public Adapter createOperationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Content <em>Content</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Content
	 * @generated
	 */
	public Adapter createContentAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Path <em>Path</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Path
	 * @generated
	 */
	public Adapter createPathAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.NamedElement <em>Named Element</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.NamedElement
	 * @generated
	 */
	public Adapter createNamedElementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Mkdir <em>Mkdir</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Mkdir
	 * @generated
	 */
	public Adapter createMkdirAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Copy <em>Copy</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Copy
	 * @generated
	 */
	public Adapter createCopyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Zip <em>Zip</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Zip
	 * @generated
	 */
	public Adapter createZipAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Move <em>Move</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Move
	 * @generated
	 */
	public Adapter createMoveAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Rename <em>Rename</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Rename
	 * @generated
	 */
	public Adapter createRenameAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Delete <em>Delete</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Delete
	 * @generated
	 */
	public Adapter createDeleteAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.SvnCommit <em>Svn Commit</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.SvnCommit
	 * @generated
	 */
	public Adapter createSvnCommitAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.SvnUpdate <em>Svn Update</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.SvnUpdate
	 * @generated
	 */
	public Adapter createSvnUpdateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.GitCommit <em>Git Commit</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.GitCommit
	 * @generated
	 */
	public Adapter createGitCommitAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.GitUpdate <em>Git Update</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.GitUpdate
	 * @generated
	 */
	public Adapter createGitUpdateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Java <em>Java</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Java
	 * @generated
	 */
	public Adapter createJavaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Exe <em>Exe</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Exe
	 * @generated
	 */
	public Adapter createExeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Clipboard <em>Clipboard</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Clipboard
	 * @generated
	 */
	public Adapter createClipboardAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.StringSeparator <em>String Separator</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.StringSeparator
	 * @generated
	 */
	public Adapter createStringSeparatorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.StringSplitter <em>String Splitter</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.StringSplitter
	 * @generated
	 */
	public Adapter createStringSplitterAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.StringReplacer <em>String Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.StringReplacer
	 * @generated
	 */
	public Adapter createStringReplacerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.StringToXls <em>String To Xls</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.StringToXls
	 * @generated
	 */
	public Adapter createStringToXlsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.StringToFile <em>String To File</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.StringToFile
	 * @generated
	 */
	public Adapter createStringToFileAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.QuestionDialog <em>Question Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.QuestionDialog
	 * @generated
	 */
	public Adapter createQuestionDialogAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.InfoDialog <em>Info Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.InfoDialog
	 * @generated
	 */
	public Adapter createInfoDialogAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.MessageDialog <em>Message Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.MessageDialog
	 * @generated
	 */
	public Adapter createMessageDialogAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.SelectionDialog <em>Selection Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.SelectionDialog
	 * @generated
	 */
	public Adapter createSelectionDialogAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.FilteredDialog <em>Filtered Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.FilteredDialog
	 * @generated
	 */
	public Adapter createFilteredDialogAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Email <em>Email</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Email
	 * @generated
	 */
	public Adapter createEmailAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Chart <em>Chart</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Chart
	 * @generated
	 */
	public Adapter createChartAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Point <em>Point</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Point
	 * @generated
	 */
	public Adapter createPointAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.LineChart <em>Line Chart</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.LineChart
	 * @generated
	 */
	public Adapter createLineChartAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.BarChart <em>Bar Chart</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.BarChart
	 * @generated
	 */
	public Adapter createBarChartAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.ScatterChart <em>Scatter Chart</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.ScatterChart
	 * @generated
	 */
	public Adapter createScatterChartAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.PieChart <em>Pie Chart</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.PieChart
	 * @generated
	 */
	public Adapter createPieChartAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.StringToList <em>String To List</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.StringToList
	 * @generated
	 */
	public Adapter createStringToListAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Sorter <em>Sorter</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Sorter
	 * @generated
	 */
	public Adapter createSorterAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.List <em>List</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.List
	 * @generated
	 */
	public Adapter createListAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Item <em>Item</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Item
	 * @generated
	 */
	public Adapter createItemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Replacement <em>Replacement</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Replacement
	 * @generated
	 */
	public Adapter createReplacementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Replacer <em>Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Replacer
	 * @generated
	 */
	public Adapter createReplacerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.OptionReplacer <em>Option Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.OptionReplacer
	 * @generated
	 */
	public Adapter createOptionReplacerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Option <em>Option</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Option
	 * @generated
	 */
	public Adapter createOptionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.InputReplacer <em>Input Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.InputReplacer
	 * @generated
	 */
	public Adapter createInputReplacerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.TimestampReplacer <em>Timestamp Replacer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.TimestampReplacer
	 * @generated
	 */
	public Adapter createTimestampReplacerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.InputDialog <em>Input Dialog</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.InputDialog
	 * @generated
	 */
	public Adapter createInputDialogAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.TextControl <em>Text Control</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.TextControl
	 * @generated
	 */
	public Adapter createTextControlAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.DateControl <em>Date Control</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.DateControl
	 * @generated
	 */
	public Adapter createDateControlAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.ComboControl <em>Combo Control</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.ComboControl
	 * @generated
	 */
	public Adapter createComboControlAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.ComboItem <em>Combo Item</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.ComboItem
	 * @generated
	 */
	public Adapter createComboItemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link de.dc.xcore.workflow.model.Control <em>Control</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see de.dc.xcore.workflow.model.Control
	 * @generated
	 */
	public Adapter createControlAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //WorkflowAdapterFactory
