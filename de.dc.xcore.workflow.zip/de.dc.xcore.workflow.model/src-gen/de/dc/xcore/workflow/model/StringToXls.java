/**
 */
package de.dc.xcore.workflow.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>String To Xls</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getStringToXls()
 * @model
 * @generated
 */
public interface StringToXls extends Clipboard {
} // StringToXls
