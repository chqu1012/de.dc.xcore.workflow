/**
 */
package de.dc.xcore.workflow.model;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mkdir</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.xcore.workflow.model.Mkdir#getPath <em>Path</em>}</li>
 *   <li>{@link de.dc.xcore.workflow.model.Mkdir#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getMkdir()
 * @model
 * @generated
 */
public interface Mkdir extends Operation {
	/**
	 * Returns the value of the '<em><b>Path</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Path</em>' containment reference.
	 * @see #setPath(Path)
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getMkdir_Path()
	 * @model containment="true"
	 * @generated
	 */
	Path getPath();

	/**
	 * Sets the value of the '{@link de.dc.xcore.workflow.model.Mkdir#getPath <em>Path</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Path</em>' containment reference.
	 * @see #getPath()
	 * @generated
	 */
	void setPath(Path value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' containment reference list.
	 * The list contents are of type {@link de.dc.xcore.workflow.model.NamedElement}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' containment reference list.
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getMkdir_Name()
	 * @model containment="true"
	 * @generated
	 */
	EList<NamedElement> getName();

} // Mkdir
