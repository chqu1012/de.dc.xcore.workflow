/**
 */
package de.dc.xcore.workflow.model;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Chart</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.xcore.workflow.model.Chart#getTitle <em>Title</em>}</li>
 *   <li>{@link de.dc.xcore.workflow.model.Chart#getXTitle <em>XTitle</em>}</li>
 *   <li>{@link de.dc.xcore.workflow.model.Chart#getYTitle <em>YTitle</em>}</li>
 *   <li>{@link de.dc.xcore.workflow.model.Chart#getPoints <em>Points</em>}</li>
 * </ul>
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getChart()
 * @model abstract="true"
 * @generated
 */
public interface Chart extends EObject {
	/**
	 * Returns the value of the '<em><b>Title</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Title</em>' attribute.
	 * @see #setTitle(String)
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getChart_Title()
	 * @model default="" unique="false"
	 * @generated
	 */
	String getTitle();

	/**
	 * Sets the value of the '{@link de.dc.xcore.workflow.model.Chart#getTitle <em>Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Title</em>' attribute.
	 * @see #getTitle()
	 * @generated
	 */
	void setTitle(String value);

	/**
	 * Returns the value of the '<em><b>XTitle</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>XTitle</em>' attribute.
	 * @see #setXTitle(String)
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getChart_XTitle()
	 * @model default="" unique="false"
	 * @generated
	 */
	String getXTitle();

	/**
	 * Sets the value of the '{@link de.dc.xcore.workflow.model.Chart#getXTitle <em>XTitle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>XTitle</em>' attribute.
	 * @see #getXTitle()
	 * @generated
	 */
	void setXTitle(String value);

	/**
	 * Returns the value of the '<em><b>YTitle</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>YTitle</em>' attribute.
	 * @see #setYTitle(String)
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getChart_YTitle()
	 * @model default="" unique="false"
	 * @generated
	 */
	String getYTitle();

	/**
	 * Sets the value of the '{@link de.dc.xcore.workflow.model.Chart#getYTitle <em>YTitle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>YTitle</em>' attribute.
	 * @see #getYTitle()
	 * @generated
	 */
	void setYTitle(String value);

	/**
	 * Returns the value of the '<em><b>Points</b></em>' containment reference list.
	 * The list contents are of type {@link de.dc.xcore.workflow.model.Point}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Points</em>' containment reference list.
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getChart_Points()
	 * @model containment="true"
	 * @generated
	 */
	EList<Point> getPoints();

} // Chart
