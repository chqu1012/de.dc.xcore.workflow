/**
 */
package de.dc.xcore.workflow.model;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Combo Control</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.xcore.workflow.model.ComboControl#getItems <em>Items</em>}</li>
 * </ul>
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getComboControl()
 * @model
 * @generated
 */
public interface ComboControl extends Control {
	/**
	 * Returns the value of the '<em><b>Items</b></em>' containment reference list.
	 * The list contents are of type {@link de.dc.xcore.workflow.model.ComboItem}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Items</em>' containment reference list.
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getComboControl_Items()
	 * @model containment="true"
	 * @generated
	 */
	EList<ComboItem> getItems();

} // ComboControl
