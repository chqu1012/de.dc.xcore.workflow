/**
 */
package de.dc.xcore.workflow.model.impl;

import de.dc.xcore.workflow.model.SvnCommit;
import de.dc.xcore.workflow.model.WorkflowPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Svn Commit</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SvnCommitImpl extends OperationImpl implements SvnCommit {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SvnCommitImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WorkflowPackage.Literals.SVN_COMMIT;
	}

} //SvnCommitImpl
