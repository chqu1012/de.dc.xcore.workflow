/**
 */
package de.dc.xcore.workflow.model;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Operation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getOperation()
 * @model abstract="true"
 * @generated
 */
public interface Operation extends EObject {
} // Operation
