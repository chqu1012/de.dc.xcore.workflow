/**
 */
package de.dc.xcore.workflow.model.impl;

import de.dc.xcore.workflow.model.StringSplitter;
import de.dc.xcore.workflow.model.WorkflowPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>String Splitter</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link de.dc.xcore.workflow.model.impl.StringSplitterImpl#getSplitBy <em>Split By</em>}</li>
 * </ul>
 *
 * @generated
 */
public class StringSplitterImpl extends ClipboardImpl implements StringSplitter {
	/**
	 * The default value of the '{@link #getSplitBy() <em>Split By</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSplitBy()
	 * @generated
	 * @ordered
	 */
	protected static final String SPLIT_BY_EDEFAULT = "";

	/**
	 * The cached value of the '{@link #getSplitBy() <em>Split By</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSplitBy()
	 * @generated
	 * @ordered
	 */
	protected String splitBy = SPLIT_BY_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StringSplitterImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WorkflowPackage.Literals.STRING_SPLITTER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getSplitBy() {
		return splitBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSplitBy(String newSplitBy) {
		String oldSplitBy = splitBy;
		splitBy = newSplitBy;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WorkflowPackage.STRING_SPLITTER__SPLIT_BY, oldSplitBy, splitBy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case WorkflowPackage.STRING_SPLITTER__SPLIT_BY:
				return getSplitBy();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case WorkflowPackage.STRING_SPLITTER__SPLIT_BY:
				setSplitBy((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case WorkflowPackage.STRING_SPLITTER__SPLIT_BY:
				setSplitBy(SPLIT_BY_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case WorkflowPackage.STRING_SPLITTER__SPLIT_BY:
				return SPLIT_BY_EDEFAULT == null ? splitBy != null : !SPLIT_BY_EDEFAULT.equals(splitBy);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (splitBy: ");
		result.append(splitBy);
		result.append(')');
		return result.toString();
	}

} //StringSplitterImpl
