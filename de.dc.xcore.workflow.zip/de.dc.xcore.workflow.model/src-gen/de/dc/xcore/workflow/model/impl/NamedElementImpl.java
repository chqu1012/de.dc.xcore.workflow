/**
 */
package de.dc.xcore.workflow.model.impl;

import de.dc.xcore.workflow.model.NamedElement;
import de.dc.xcore.workflow.model.WorkflowPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Named Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class NamedElementImpl extends ContentImpl implements NamedElement {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NamedElementImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WorkflowPackage.Literals.NAMED_ELEMENT;
	}

} //NamedElementImpl
