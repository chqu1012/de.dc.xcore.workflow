/**
 */
package de.dc.xcore.workflow.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Copy</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.xcore.workflow.model.Copy#getSource <em>Source</em>}</li>
 *   <li>{@link de.dc.xcore.workflow.model.Copy#getDestination <em>Destination</em>}</li>
 * </ul>
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getCopy()
 * @model
 * @generated
 */
public interface Copy extends Operation {
	/**
	 * Returns the value of the '<em><b>Source</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' containment reference.
	 * @see #setSource(Path)
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getCopy_Source()
	 * @model containment="true"
	 * @generated
	 */
	Path getSource();

	/**
	 * Sets the value of the '{@link de.dc.xcore.workflow.model.Copy#getSource <em>Source</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' containment reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(Path value);

	/**
	 * Returns the value of the '<em><b>Destination</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Destination</em>' containment reference.
	 * @see #setDestination(Path)
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getCopy_Destination()
	 * @model containment="true"
	 * @generated
	 */
	Path getDestination();

	/**
	 * Sets the value of the '{@link de.dc.xcore.workflow.model.Copy#getDestination <em>Destination</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Destination</em>' containment reference.
	 * @see #getDestination()
	 * @generated
	 */
	void setDestination(Path value);

} // Copy
