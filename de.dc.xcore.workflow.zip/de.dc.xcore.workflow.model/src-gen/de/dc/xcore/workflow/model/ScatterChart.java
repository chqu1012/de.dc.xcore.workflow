/**
 */
package de.dc.xcore.workflow.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Scatter Chart</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getScatterChart()
 * @model
 * @generated
 */
public interface ScatterChart extends Chart {
} // ScatterChart
