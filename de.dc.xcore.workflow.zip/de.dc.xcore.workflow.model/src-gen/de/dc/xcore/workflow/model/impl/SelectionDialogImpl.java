/**
 */
package de.dc.xcore.workflow.model.impl;

import de.dc.xcore.workflow.model.SelectionDialog;
import de.dc.xcore.workflow.model.WorkflowPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Selection Dialog</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SelectionDialogImpl extends MinimalEObjectImpl.Container implements SelectionDialog {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SelectionDialogImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WorkflowPackage.Literals.SELECTION_DIALOG;
	}

} //SelectionDialogImpl
