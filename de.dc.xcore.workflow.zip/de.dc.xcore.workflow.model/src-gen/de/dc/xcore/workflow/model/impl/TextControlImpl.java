/**
 */
package de.dc.xcore.workflow.model.impl;

import de.dc.xcore.workflow.model.TextControl;
import de.dc.xcore.workflow.model.WorkflowPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Text Control</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class TextControlImpl extends ControlImpl implements TextControl {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TextControlImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WorkflowPackage.Literals.TEXT_CONTROL;
	}

} //TextControlImpl
