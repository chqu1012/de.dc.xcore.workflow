/**
 */
package de.dc.xcore.workflow.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Line Chart</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getLineChart()
 * @model
 * @generated
 */
public interface LineChart extends Chart {
} // LineChart
