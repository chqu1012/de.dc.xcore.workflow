/**
 */
package de.dc.xcore.workflow.model.impl;

import de.dc.xcore.workflow.model.BarChart;
import de.dc.xcore.workflow.model.WorkflowPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Bar Chart</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class BarChartImpl extends ChartImpl implements BarChart {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BarChartImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WorkflowPackage.Literals.BAR_CHART;
	}

} //BarChartImpl
