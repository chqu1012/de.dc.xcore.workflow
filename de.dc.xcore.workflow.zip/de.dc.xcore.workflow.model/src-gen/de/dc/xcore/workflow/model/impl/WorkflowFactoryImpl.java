/**
 */
package de.dc.xcore.workflow.model.impl;

import de.dc.xcore.workflow.model.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class WorkflowFactoryImpl extends EFactoryImpl implements WorkflowFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static WorkflowFactory init() {
		try {
			WorkflowFactory theWorkflowFactory = (WorkflowFactory)EPackage.Registry.INSTANCE.getEFactory(WorkflowPackage.eNS_URI);
			if (theWorkflowFactory != null) {
				return theWorkflowFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new WorkflowFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WorkflowFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case WorkflowPackage.WORKFLOW_MANAGER: return createWorkflowManager();
			case WorkflowPackage.WORKFLOW: return createWorkflow();
			case WorkflowPackage.PATH: return createPath();
			case WorkflowPackage.NAMED_ELEMENT: return createNamedElement();
			case WorkflowPackage.MKDIR: return createMkdir();
			case WorkflowPackage.COPY: return createCopy();
			case WorkflowPackage.ZIP: return createZip();
			case WorkflowPackage.MOVE: return createMove();
			case WorkflowPackage.RENAME: return createRename();
			case WorkflowPackage.DELETE: return createDelete();
			case WorkflowPackage.SVN_COMMIT: return createSvnCommit();
			case WorkflowPackage.SVN_UPDATE: return createSvnUpdate();
			case WorkflowPackage.GIT_COMMIT: return createGitCommit();
			case WorkflowPackage.GIT_UPDATE: return createGitUpdate();
			case WorkflowPackage.JAVA: return createJava();
			case WorkflowPackage.EXE: return createExe();
			case WorkflowPackage.CLIPBOARD: return createClipboard();
			case WorkflowPackage.STRING_SEPARATOR: return createStringSeparator();
			case WorkflowPackage.STRING_SPLITTER: return createStringSplitter();
			case WorkflowPackage.STRING_REPLACER: return createStringReplacer();
			case WorkflowPackage.STRING_TO_XLS: return createStringToXls();
			case WorkflowPackage.STRING_TO_FILE: return createStringToFile();
			case WorkflowPackage.QUESTION_DIALOG: return createQuestionDialog();
			case WorkflowPackage.INFO_DIALOG: return createInfoDialog();
			case WorkflowPackage.MESSAGE_DIALOG: return createMessageDialog();
			case WorkflowPackage.SELECTION_DIALOG: return createSelectionDialog();
			case WorkflowPackage.FILTERED_DIALOG: return createFilteredDialog();
			case WorkflowPackage.EMAIL: return createEmail();
			case WorkflowPackage.POINT: return createPoint();
			case WorkflowPackage.LINE_CHART: return createLineChart();
			case WorkflowPackage.BAR_CHART: return createBarChart();
			case WorkflowPackage.SCATTER_CHART: return createScatterChart();
			case WorkflowPackage.PIE_CHART: return createPieChart();
			case WorkflowPackage.STRING_TO_LIST: return createStringToList();
			case WorkflowPackage.SORTER: return createSorter();
			case WorkflowPackage.LIST: return createList();
			case WorkflowPackage.ITEM: return createItem();
			case WorkflowPackage.REPLACEMENT: return createReplacement();
			case WorkflowPackage.OPTION_REPLACER: return createOptionReplacer();
			case WorkflowPackage.OPTION: return createOption();
			case WorkflowPackage.INPUT_REPLACER: return createInputReplacer();
			case WorkflowPackage.TIMESTAMP_REPLACER: return createTimestampReplacer();
			case WorkflowPackage.INPUT_DIALOG: return createInputDialog();
			case WorkflowPackage.TEXT_CONTROL: return createTextControl();
			case WorkflowPackage.DATE_CONTROL: return createDateControl();
			case WorkflowPackage.COMBO_CONTROL: return createComboControl();
			case WorkflowPackage.COMBO_ITEM: return createComboItem();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public WorkflowManager createWorkflowManager() {
		WorkflowManagerImpl workflowManager = new WorkflowManagerImpl();
		return workflowManager;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Workflow createWorkflow() {
		WorkflowImpl workflow = new WorkflowImpl();
		return workflow;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Path createPath() {
		PathImpl path = new PathImpl();
		return path;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NamedElement createNamedElement() {
		NamedElementImpl namedElement = new NamedElementImpl();
		return namedElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Mkdir createMkdir() {
		MkdirImpl mkdir = new MkdirImpl();
		return mkdir;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Copy createCopy() {
		CopyImpl copy = new CopyImpl();
		return copy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Zip createZip() {
		ZipImpl zip = new ZipImpl();
		return zip;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Move createMove() {
		MoveImpl move = new MoveImpl();
		return move;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Rename createRename() {
		RenameImpl rename = new RenameImpl();
		return rename;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Delete createDelete() {
		DeleteImpl delete = new DeleteImpl();
		return delete;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SvnCommit createSvnCommit() {
		SvnCommitImpl svnCommit = new SvnCommitImpl();
		return svnCommit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SvnUpdate createSvnUpdate() {
		SvnUpdateImpl svnUpdate = new SvnUpdateImpl();
		return svnUpdate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public GitCommit createGitCommit() {
		GitCommitImpl gitCommit = new GitCommitImpl();
		return gitCommit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public GitUpdate createGitUpdate() {
		GitUpdateImpl gitUpdate = new GitUpdateImpl();
		return gitUpdate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Java createJava() {
		JavaImpl java = new JavaImpl();
		return java;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Exe createExe() {
		ExeImpl exe = new ExeImpl();
		return exe;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Clipboard createClipboard() {
		ClipboardImpl clipboard = new ClipboardImpl();
		return clipboard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public StringSeparator createStringSeparator() {
		StringSeparatorImpl stringSeparator = new StringSeparatorImpl();
		return stringSeparator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public StringSplitter createStringSplitter() {
		StringSplitterImpl stringSplitter = new StringSplitterImpl();
		return stringSplitter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public StringReplacer createStringReplacer() {
		StringReplacerImpl stringReplacer = new StringReplacerImpl();
		return stringReplacer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public StringToXls createStringToXls() {
		StringToXlsImpl stringToXls = new StringToXlsImpl();
		return stringToXls;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public StringToFile createStringToFile() {
		StringToFileImpl stringToFile = new StringToFileImpl();
		return stringToFile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public QuestionDialog createQuestionDialog() {
		QuestionDialogImpl questionDialog = new QuestionDialogImpl();
		return questionDialog;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InfoDialog createInfoDialog() {
		InfoDialogImpl infoDialog = new InfoDialogImpl();
		return infoDialog;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MessageDialog createMessageDialog() {
		MessageDialogImpl messageDialog = new MessageDialogImpl();
		return messageDialog;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SelectionDialog createSelectionDialog() {
		SelectionDialogImpl selectionDialog = new SelectionDialogImpl();
		return selectionDialog;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FilteredDialog createFilteredDialog() {
		FilteredDialogImpl filteredDialog = new FilteredDialogImpl();
		return filteredDialog;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Email createEmail() {
		EmailImpl email = new EmailImpl();
		return email;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Point createPoint() {
		PointImpl point = new PointImpl();
		return point;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LineChart createLineChart() {
		LineChartImpl lineChart = new LineChartImpl();
		return lineChart;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BarChart createBarChart() {
		BarChartImpl barChart = new BarChartImpl();
		return barChart;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ScatterChart createScatterChart() {
		ScatterChartImpl scatterChart = new ScatterChartImpl();
		return scatterChart;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PieChart createPieChart() {
		PieChartImpl pieChart = new PieChartImpl();
		return pieChart;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public StringToList createStringToList() {
		StringToListImpl stringToList = new StringToListImpl();
		return stringToList;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Sorter createSorter() {
		SorterImpl sorter = new SorterImpl();
		return sorter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List createList() {
		ListImpl list = new ListImpl();
		return list;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Item createItem() {
		ItemImpl item = new ItemImpl();
		return item;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Replacement createReplacement() {
		ReplacementImpl replacement = new ReplacementImpl();
		return replacement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public OptionReplacer createOptionReplacer() {
		OptionReplacerImpl optionReplacer = new OptionReplacerImpl();
		return optionReplacer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Option createOption() {
		OptionImpl option = new OptionImpl();
		return option;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InputReplacer createInputReplacer() {
		InputReplacerImpl inputReplacer = new InputReplacerImpl();
		return inputReplacer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TimestampReplacer createTimestampReplacer() {
		TimestampReplacerImpl timestampReplacer = new TimestampReplacerImpl();
		return timestampReplacer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InputDialog createInputDialog() {
		InputDialogImpl inputDialog = new InputDialogImpl();
		return inputDialog;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TextControl createTextControl() {
		TextControlImpl textControl = new TextControlImpl();
		return textControl;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DateControl createDateControl() {
		DateControlImpl dateControl = new DateControlImpl();
		return dateControl;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ComboControl createComboControl() {
		ComboControlImpl comboControl = new ComboControlImpl();
		return comboControl;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ComboItem createComboItem() {
		ComboItemImpl comboItem = new ComboItemImpl();
		return comboItem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public WorkflowPackage getWorkflowPackage() {
		return (WorkflowPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static WorkflowPackage getPackage() {
		return WorkflowPackage.eINSTANCE;
	}

} //WorkflowFactoryImpl
