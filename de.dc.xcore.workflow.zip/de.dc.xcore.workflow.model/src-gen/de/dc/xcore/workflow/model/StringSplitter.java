/**
 */
package de.dc.xcore.workflow.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>String Splitter</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link de.dc.xcore.workflow.model.StringSplitter#getSplitBy <em>Split By</em>}</li>
 * </ul>
 *
 * @see de.dc.xcore.workflow.model.WorkflowPackage#getStringSplitter()
 * @model
 * @generated
 */
public interface StringSplitter extends Clipboard {
	/**
	 * Returns the value of the '<em><b>Split By</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Split By</em>' attribute.
	 * @see #setSplitBy(String)
	 * @see de.dc.xcore.workflow.model.WorkflowPackage#getStringSplitter_SplitBy()
	 * @model default="" unique="false"
	 * @generated
	 */
	String getSplitBy();

	/**
	 * Sets the value of the '{@link de.dc.xcore.workflow.model.StringSplitter#getSplitBy <em>Split By</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Split By</em>' attribute.
	 * @see #getSplitBy()
	 * @generated
	 */
	void setSplitBy(String value);

} // StringSplitter
