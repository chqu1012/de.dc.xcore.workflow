package de.dc.xcore.workflow.model.provider;

import org.eclipse.emf.common.notify.AdapterFactory;

import de.dc.xcore.workflow.model.Exe;

public class ExtExeItemProvider extends ExeItemProvider {

	public ExtExeItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	@Override
	public String getText(Object object) {
		Exe exe = (Exe) object;
		String path = exe.getPath().getContent();
		return "Exe "+path;
	}
}
