package de.dc.xcore.workflow.model.listener;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.IStructuredSelection;

import de.dc.xcore.workflow.model.switcher.OperationSwitch;

public class OperationDoubleClickListener implements IDoubleClickListener {

	OperationSwitch switcher = new OperationSwitch();
	
	@Override
	public void doubleClick(DoubleClickEvent event) {
		IStructuredSelection selection = (IStructuredSelection) event.getSelection();
		switcher.doSwitch((EObject) selection.getFirstElement());
	}
}
