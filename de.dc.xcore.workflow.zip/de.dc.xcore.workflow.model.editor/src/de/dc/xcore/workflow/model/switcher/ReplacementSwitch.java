package de.dc.xcore.workflow.model.switcher;

import java.text.SimpleDateFormat;

import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.swt.widgets.Shell;

import de.dc.xcore.workflow.model.InputReplacer;
import de.dc.xcore.workflow.model.TimestampReplacer;
import de.dc.xcore.workflow.model.util.WorkflowSwitch;

public class ReplacementSwitch extends WorkflowSwitch<String> {

	@Override
	public String caseInputReplacer(InputReplacer object) {
		InputDialog id = new InputDialog(new Shell(), object.getTitle(), object.getMessage(), null, null);
		int code = id.open();
		if (code==0) {
			return id.getValue();
		}
		return super.caseInputReplacer(object);
	}
	
	@Override
	public String caseTimestampReplacer(TimestampReplacer object) {
		SimpleDateFormat sdf = new SimpleDateFormat(object.getFormatter());
		return sdf.format(System.currentTimeMillis());
	}
}
