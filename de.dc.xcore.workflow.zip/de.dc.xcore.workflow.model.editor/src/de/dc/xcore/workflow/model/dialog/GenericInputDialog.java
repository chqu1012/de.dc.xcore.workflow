package de.dc.xcore.workflow.model.dialog;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import de.dc.xcore.workflow.model.ComboControl;
import de.dc.xcore.workflow.model.ComboItem;
import de.dc.xcore.workflow.model.DateControl;
import de.dc.xcore.workflow.model.InputDialog;
import de.dc.xcore.workflow.model.TextControl;

import org.eclipse.swt.layout.GridLayout;

public class GenericInputDialog extends TitleAreaDialog {
	
	private HashMap<Control, de.dc.xcore.workflow.model.Control> controls = new HashMap<>();

	private InputDialog model;
	
	public GenericInputDialog(InputDialog model) {
		super(new Shell());
		this.model = model;
	}

	@Override
	protected Control createDialogArea(Composite parent) {
		setTitle(model.getTitle());
		setMessage(model.getDescription());
		
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayout(new GridLayout(2, false));
		container.setLayoutData(new GridData(GridData.FILL_BOTH));

		for (de.dc.xcore.workflow.model.Control control : model.getControls()) {
			new Label(container, 0).setText(control.getContent());
			if (control instanceof TextControl) {
				TextControl tc = (TextControl) control;
				Text text = new Text(container, SWT.SINGLE | SWT.LEAD | SWT.BORDER);
				text.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));
				if (control instanceof DateControl) {
					DateControl dc = (DateControl) control;
					SimpleDateFormat sdf = new SimpleDateFormat(dc.getFormatter());
					String dateText = sdf.format(new Date());
					text.setMessage(dc.getFormatter());
					text.setText(dateText);
				}else{
					text.setMessage(control.getContent());
				}
				controls.put(text, tc);
			}else if (control instanceof ComboControl) {
				ComboControl cc = (ComboControl) control;
				Combo combo = new Combo(container, SWT.DROP_DOWN | SWT.READ_ONLY);
				combo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));
				List<String> items = new ArrayList<>();
				for (ComboItem ci : cc.getItems()) {
					items.add(ci.getValue()+'-'+ci.getContent());
				}
				combo.setItems(items.toArray(new String[0]));
				combo.select(0);
				controls.put(combo, cc);
			}
		}
		
		return area;
	}
	
	@Override
	protected void buttonPressed(int buttonId) {
		boolean canClose = true;
		if (buttonId==OK) {
			for (Entry<Control, de.dc.xcore.workflow.model.Control> controls : controls.entrySet()) {
				Control swtControl = controls.getKey();
				if (swtControl instanceof Text) {
					Text text = (Text) swtControl;
					if (text.getText()==null || text.getText().length()==0) {
						canClose=false;
					}else{
						controls.getValue().setValue(text.getText());
					}
				}else if (swtControl instanceof Combo) {
					Combo combo = (Combo) swtControl;
					String text = combo.getText();
					controls.getValue().setValue(text);
				}
				System.out.println(controls.getValue());
			}
		}
		if(canClose){
			super.buttonPressed(buttonId);
		}else{
			setErrorMessage("Alle Pflichtfelder m�ssen ausgef�llt werden!");
		}
	}

	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, true);
		createButton(parent, IDialogConstants.CANCEL_ID, IDialogConstants.CANCEL_LABEL, false);
	}

	@Override
	protected Point getInitialSize() {
		return new Point(model.getWidth(), model.getHeight());
	}

}
