package de.dc.xcore.workflow.model.switcher;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.List;

import org.eclipse.swt.dnd.RTFTransfer;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.dnd.TransferData;
import org.eclipse.swt.widgets.Display;

import de.dc.xcore.workflow.model.Clipboard;
import de.dc.xcore.workflow.model.Exe;
import de.dc.xcore.workflow.model.InputDialog;
import de.dc.xcore.workflow.model.Mkdir;
import de.dc.xcore.workflow.model.Path;
import de.dc.xcore.workflow.model.Replacement;
import de.dc.xcore.workflow.model.StringReplacer;
import de.dc.xcore.workflow.model.StringSeparator;
import de.dc.xcore.workflow.model.dialog.GenericInputDialog;
import de.dc.xcore.workflow.model.util.WorkflowSwitch;

public class OperationSwitch extends WorkflowSwitch<Object> {

	private ReplacementSwitch replaceSwith = new ReplacementSwitch();
	
	@Override
	public Object caseInputDialog(InputDialog object) {
		 GenericInputDialog dialog = new GenericInputDialog(object);
		 dialog.open();
		 return super.caseInputDialog(object);
	}
	
	@Override
	public Object caseExe(Exe object) {
		Path path = object.getPath();
		if (path!=null) {
			open(path.getContent());
		}
		return null;
	}
	
	@Override
	public Object caseClipboard(Clipboard object) {
		String content = object.getContent();
		System.out.println("ORIGINAL: "+content);
		for (Replacement replacement : object.getReplacements()) {
			String c = replaceSwith.doSwitch(replacement.getReplacer());
			if(c!=null){
				content = content.replaceAll(replacement.getVariable(), c);
			}
		}
		System.out.println("ERSETZT: "+content);
		return super.caseClipboard(object);
	}
	
	@Override
	public Object caseMkdir(Mkdir object) {
		Path path = object.getPath();
		String pathContent = path.getContent();
		replace(pathContent, path.getReplacements());
		File folder = new File(pathContent);
		folder.mkdir();
		return super.caseMkdir(object);
	}

	private void replace(String pathContent, List<Replacement> replacements) {
		for (Replacement replacement : replacements) {
			String content = replaceSwith.doSwitch(replacement.getReplacer());
			pathContent.replaceAll(replacement.getVariable(), content);
		}
	}
	
	@Override
	public Object caseStringSeparator(StringSeparator object) {
		String paste = paste();
		paste = paste.replaceAll(object.getLineSeparator(), "\n");
		replace(paste, object.getReplacements());
		copy(paste);
		return super.caseStringSeparator(object);
	}
	
	@Override
	public Object caseStringReplacer(StringReplacer object) {
		String paste = paste();
		paste = paste.replaceAll(object.getRegex(), object.getReplacer());
		replace(paste, object.getReplacements());
		copy(paste);
		return super.caseStringReplacer(object);
	}
	
	@Override
	public Object casePath(Path object) {
		open(object.getContent());
		return super.casePath(object);
	}
	
	private String paste(){
		org.eclipse.swt.dnd.Clipboard clipboard = new org.eclipse.swt.dnd.Clipboard(Display.getCurrent());
        TransferData[] transferDatas = clipboard.getAvailableTypes();
        for(int i=0; i<transferDatas.length; i++) {
          // Checks whether RTF format is available.
          if(RTFTransfer.getInstance().isSupportedType(transferDatas[i])) {
            System.out.println("Data is available in RTF format");
            break;
          }
        }
        String plainText = (String)clipboard.getContents(TextTransfer.getInstance());
        clipboard.dispose();
        return plainText;
	}
	
	private void copy(String text){
		org.eclipse.swt.dnd.Clipboard clipboard = new org.eclipse.swt.dnd.Clipboard(Display.getCurrent());
        TextTransfer textTransfer = TextTransfer.getInstance();
        clipboard.setContents(new String[]{text}, new Transfer[]{textTransfer});
        clipboard.dispose();
	}

	private void open(String path) {
		try {
			File file = new File(path);
			Desktop.getDesktop().open(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
